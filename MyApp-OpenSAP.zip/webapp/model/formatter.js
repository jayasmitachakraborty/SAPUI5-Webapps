sap.ui.define([],function(){
	
	"use strict";
	return{
		delivery : function(unitMeasure, weight) {
			
			var oResourceBundle = this.getView().getModel("i18n").getResourceBundle(), result = "";
			if (unitMeasure === "G")
				weight = weight/1000;
			
			if (weight < 0.6)
				result = oResourceBundle.getText("formatterMailDelivery");
			else if (weight < 5)
				result = oResourceBundle.getText("formatterParcelDelivery");
			else
				result = oResourceBundle.getText("formatterCarrierDelivery");
			return result;
		},
		
		weight : function(weight){
			
			if (weight<0.2)
				return "Success";
			else if (weight<5)
				return "None";
			else
				return "Warning";
		},
		
		symbol : function(price, currency){
			
			if(currency === "USD")
				return ("$"+price);
			else if(currency === "EUR")
				return ("€"+price);
			else
				return (currency+price);
		}
	};
});