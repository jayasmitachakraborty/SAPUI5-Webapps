sap.ui.define([
	"sap/ui/model/SimpleType"
	], 
	
	function(SimpleType){
		"use strict";
		return SimpleType.extend("MyApp-OpenSAP.model.customType",{
			//formats ui representation, formatOptions section
			formatValue : function(){
				
			},
			//parsing for writing back into mode
			parseValue : function(){
				
			},
			//validates the value to be parsed, contraints are defined here
			validateValue : function(){
				
			}
			
		});
	});